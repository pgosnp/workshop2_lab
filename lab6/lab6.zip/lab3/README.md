# lab3

a [Sails](http://sailsjs.org) application
